<!DOCTYPE html>
<html>
<head/>
<body>
<div>
<?php
$tainted = `cat /tmp/tainted.txt`;

//no_sanitizing

//flaw
echo $tainted ;
?>
</div>
<h1>Hello World!</h1>
</body>
</html>
