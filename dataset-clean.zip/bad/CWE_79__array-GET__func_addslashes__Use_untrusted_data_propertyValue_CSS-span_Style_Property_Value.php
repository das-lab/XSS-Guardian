<!DOCTYPE html>
<html>
<head/>
<body>
<?php
$array = array();
$array[] = 'safe' ;
$array[] = $_GET['userData'] ;
$array[] = 'safe' ;
$tainted = $array[1] ;

$tainted = addslashes($tainted);

//flaw
echo "<span style=\"color :". $tainted ."\">Hey</span>" ;
?>
<h1>Hello World!</h1>
</body>
</html>
