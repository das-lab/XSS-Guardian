<!DOCTYPE html>
<html>
<head>
<!--
<?php
$tainted = `cat /tmp/tainted.txt`;

$tainted = htmlspecialchars($tainted, ENT_QUOTES);

//flaw
echo $tainted ;
?>
-->
</head>
<body>
<h1>Hello World!</h1>
</body>
</html>
