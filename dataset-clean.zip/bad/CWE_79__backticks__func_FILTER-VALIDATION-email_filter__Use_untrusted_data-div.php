<!DOCTYPE html>
<html>
<head/>
<body>
<div>
<?php
$tainted = `cat /tmp/tainted.txt`;

if (filter_var($sanitized, FILTER_VALIDATE_EMAIL))
  $tainted = $sanitized ;
else
  $tainted = "" ;

//flaw
echo $tainted ;
?>
</div>
<h1>Hello World!</h1>
</body>
</html>
