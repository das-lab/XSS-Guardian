<!DOCTYPE html>
<html>
<head>
<!--
<?php
$tainted = `cat /tmp/tainted.txt`;

$tainted = addslashes($tainted);

//flaw
echo $tainted ;
?>
-->
</head>
<body>
<h1>Hello World!</h1>
</body>
</html>
