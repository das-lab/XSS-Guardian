<!DOCTYPE html>
<html>
<head>
<!--
<?php
$tainted = `cat /tmp/tainted.txt`;

//no_sanitizing

//flaw
echo $tainted ;
?>
-->
</head>
<body>
<h1>Hello World!</h1>
</body>
</html>
