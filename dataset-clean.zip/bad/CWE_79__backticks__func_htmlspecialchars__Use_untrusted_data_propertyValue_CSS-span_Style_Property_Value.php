<!DOCTYPE html>
<html>
<head/>
<body>
<?php
$tainted = `cat /tmp/tainted.txt`;

$tainted = htmlspecialchars($tainted, ENT_QUOTES);

//flaw
echo "<span style=\"color :". $tainted ."\">Hey</span>" ;
?>
<h1>Hello World!</h1>
</body>
</html>
