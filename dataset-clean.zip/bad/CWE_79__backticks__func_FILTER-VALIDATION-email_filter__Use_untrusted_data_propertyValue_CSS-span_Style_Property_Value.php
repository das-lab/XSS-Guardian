<!DOCTYPE html>
<html>
<head/>
<body>
<?php
$tainted = `cat /tmp/tainted.txt`;

if (filter_var($sanitized, FILTER_VALIDATE_EMAIL))
  $tainted = $sanitized ;
else
  $tainted = "" ;

//flaw
echo "<span style=\"color :". $tainted ."\">Hey</span>" ;
?>
<h1>Hello World!</h1>
</body>
</html>
